'use strict';
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateUser = void 0;
const user_1 = __importDefault(require("./entity/user"));
const authenticateUseCase_1 = require("./useCase/authenticateUseCase");
const validateUser = async (event) => {
    try {
        if (event.body !== undefined && event.body !== null) {
            const userAuthCase = new authenticateUseCase_1.AuthenticateUseCase();
            // Extrair dados da requisição, se necessário
            const { email, document, name, created } = JSON.parse(event.body);
            console.log(email + " " + document + " " + " " + name + " " + created);
            const user = new user_1.default(name, email, document, created, null); // Supondo que User seja uma classe
            console.log(user);
            // Chamar o caso de uso correspondente
            const result = await userAuthCase.authenticate(user); // Supondo que userAuthCase seja um serviço ou caso de uso
            // Retornar resposta adequada
            return {
                statusCode: 200,
                body: JSON.stringify(result),
            };
        }
        else {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Corpo da solicitação não fornecido' + " Event Headers: " + event.headers + " Event Data: " + event.pathParameters + " Event body: " + event.body }),
            };
        }
    }
    catch (error) {
        // Lidar com erros e retornar resposta de erro
        console.log(event.body);
        return {
            statusCode: 500,
            body: JSON.stringify({ erro: error.message + " " + event }),
        };
    }
    // Use this code if you don't use the http event with the LAMBDA-PROXY integration
    // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };
};
exports.validateUser = validateUser;
//# sourceMappingURL=handler.js.map