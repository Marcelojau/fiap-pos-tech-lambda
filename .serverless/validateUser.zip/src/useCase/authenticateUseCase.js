"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthenticateUseCase = void 0;
const awsService_1 = __importDefault(require("../services/awsService"));
class AuthenticateUseCase {
    constructor() {
        this.cognitoService = new awsService_1.default();
    }
    async authenticate(userData) {
        const { document, email, name, created } = userData;
        try {
            if (created) {
                const tokenAcess = await this.cognitoService.authenticate(document);
                return tokenAcess;
            }
            else {
                const userId = await this.cognitoService.registerUser(email, document, name);
                return userId;
            }
        }
        catch (error) {
            console.error('Erro ao registrar usuário:', error);
            return null;
        }
    }
}
exports.AuthenticateUseCase = AuthenticateUseCase;
//# sourceMappingURL=authenticateUseCase.js.map