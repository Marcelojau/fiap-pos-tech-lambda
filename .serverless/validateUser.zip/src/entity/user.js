"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class User {
    constructor(name, email, document, created, clientId) {
        this.name = name;
        this.email = email;
        this.document = document;
        this.created = created;
    }
}
exports.default = User;
//# sourceMappingURL=user.js.map