"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AwsConfiguration = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
class AwsConfiguration {
    constructor() {
        // Configuração do AWS Cognito
        const config = {
            accessKeyId: process.env.AWS_CHAVE_KEY,
            secretAccessKey: process.env.AWS_CHAVE_SECRET,
            region: process.env.AWS_REGION_KEY
        };
        aws_sdk_1.default.config.update(config);
        this.cognito = new aws_sdk_1.default.CognitoIdentityServiceProvider();
    }
    getCognito() {
        return this.cognito;
    }
}
exports.AwsConfiguration = AwsConfiguration;
//# sourceMappingURL=awsConfiguration.js.map